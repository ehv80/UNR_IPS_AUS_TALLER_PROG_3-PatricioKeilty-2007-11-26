package myblog;


import java.util.Iterator;
import java.util.List;
import myblog.dao.BlogEntryDAO;
import myblog.dao.CommentDAO;
import myblog.dao.DataAccessException;
import myblog.dao.jdbc.JDBCBlogEntryDAO;
import myblog.dao.jdbc.JDBCCommentDAO;

public class BlogManager {
	
	private static BlogEntryDAO _blogEntryDAO = new JDBCBlogEntryDAO();
	private static CommentDAO _commentDAO = new JDBCCommentDAO();

	static public List getRecentBlogEntries() throws DataAccessException{

		List entries = _blogEntryDAO.getMostRecentBlogEntries();
		Iterator eit = entries.iterator();
		while (eit.hasNext()){
			BlogEntry e = (BlogEntry) eit.next();
			e.setComments(_commentDAO.getCommentsByBlogEntryId(e.getId()));
		}
		return entries;
	}
	
	static public void createBlogEntry(BlogEntry entry) throws DataAccessException{
		_blogEntryDAO.createBlogEntry(entry);
	}
	
	static public void updateBlogEntry(BlogEntry entry) throws DataAccessException{
		_blogEntryDAO.updateBlogEntry(entry);
	}
	

	static public void deleteBlogEntry(BlogEntry entry) throws DataAccessException{
		_commentDAO.deleteCommentsForBlogEntryId(entry.getId());
		_blogEntryDAO.deleteBlogEntry(entry);
	}
	

	static public void addCommentToBlogEntry(BlogEntry entry, Comment comment) throws DataAccessException{
		_commentDAO.createCommentForBlogEntryId(entry.getId(), comment);
		entry.addComment(comment);
	}

	public static BlogEntry getBlogEntryById(int entryIndex) throws DataAccessException {
		BlogEntry entry = _blogEntryDAO.getBlogEntryById(entryIndex);
		entry.setComments(_commentDAO.getCommentsByBlogEntryId(entry.getId()));
		return entry;
	}
	
}
