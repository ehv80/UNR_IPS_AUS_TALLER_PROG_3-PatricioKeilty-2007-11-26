package myblog.dao.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import myblog.Comment;
import myblog.dao.CommentDAO;
import myblog.dao.DataAccessException;

public class JDBCCommentDAO extends JDBCBaseDAO implements CommentDAO {

	private final String deleteQuery = "DELETE FROM comment WHERE eid = @eid@";
	private final String insertQuery = "INSERT INTO comment (author, message, eid) VALUES ('@author@', '@message@', @eid@)";
	private final String commentsQuery = "SELECT * FROM comment WHERE eid = @eid@";

	public void deleteComment(Comment comment) throws DataAccessException {
		// TODO Auto-generated method stub
	}

	public void deleteCommentsForBlogEntryId(int id) throws DataAccessException {
		  Statement stmt = null;
		  Connection conn = null;
		  try 
		  {
		    conn = getConnection();
		    stmt = conn.createStatement();
		    String query = deleteQuery.replaceAll("@eid@", String.valueOf(id));
		    stmt.executeUpdate(query);
		  } catch(Exception excepcion){
		    throw new DataAccessException(excepcion);
		  } finally {
			  try {
		    if (stmt != null)
		    	stmt.close();
		    if (conn != null)
		    	conn.close();
			  }catch (Exception e) {
				throw new DataAccessException(e); 
			}
		  }
	}

	public List getCommentsByBlogEntryId(int id) throws DataAccessException {
		List comments = new ArrayList();
		Statement stmt = null;
		Connection conn = null;

		try {
			conn = getConnection();
			stmt = conn.createStatement();
			String commQuery = commentsQuery.replaceAll("@eid@", String
					.valueOf(id));
			ResultSet rs = stmt.executeQuery(commQuery);

			while (rs.next()) {
				String author = rs.getString("author");
				String message = rs.getString("message");
				int commentId = rs.getInt("cid");
				Comment c = new Comment(author, message);
				c.setId(commentId);
				comments.add(c);
			}
		} catch (Exception excepcion) {
			throw new DataAccessException(excepcion);
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				throw new DataAccessException(e);
			}
		}
		return comments;
	}

	public void updateComment(Comment comment) throws DataAccessException {
		// TODO Auto-generated method stub
		
	}

	public void createCommentForBlogEntryId(int id, Comment comment) throws DataAccessException {
		  Statement stmt = null;
		  Connection conn = null;
		  try 
		  {
		    conn = getConnection();
		    stmt = conn.createStatement();
		    String query = insertQuery.replaceAll("@author@", comment.getAuthor()).
		        replaceAll("@message@", comment.getMessage()).
		        replaceAll("@eid@",String.valueOf(id));
		    stmt.executeUpdate(query);
		  } catch(Exception excepcion){
		    throw new DataAccessException(excepcion);
		  } finally {
			  try{
		    if (stmt != null)
		    	stmt.close();
		    if (conn != null)
		    	conn.close();
			  }catch (Exception e){
				  throw new DataAccessException(e);
			  }
		  }
	}
}
