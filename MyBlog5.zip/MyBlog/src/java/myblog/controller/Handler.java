package myblog.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface Handler {
	/**
	 * Request handler main function, process a specific request on some specific url, and 
	 * return the name of the view which will render the response.
	 * May return null if no further processing is neccessary, e.g.: some redirect has been 
	 * invoked on response.
	 *   
	 * @param request
	 * @param response
	 * @return name of the view that will render response
	 * @throws IOException
	 */
    public String process(HttpServletRequest request, HttpServletResponse response)
         throws IOException;
}
