package myblog.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * FrontController implementation for Blog application.
 *
 */
public class BlogController extends HttpServlet {

	static HashMap mapping = new HashMap();
	static {
		mapping.put("/index.do", "myblog.controller.IndexHandler");
		mapping.put("/entry.do", "myblog.controller.EntryHandler");
		mapping.put("/login.do", "myblog.controller.LoginHandler");
		mapping.put("/edit-entry.do", "myblog.controller.EntryEditHandler");
		mapping.put("/process-entry.do", "myblog.controller.ProcessEntryHandler");
		mapping.put("/logout.do", "myblog.controller.SimpleHandler");
	}

	static private Handler defaultHandler = new SimpleHandler();   

	protected void processRequest(HttpServletRequest req, HttpServletResponse res) 
	  throws ServletException, java.io.IOException {
		
		Handler handler = null;
		try {
			String controllerClassName = (String)mapping.get(req.getServletPath());
			if (controllerClassName != null)
				handler = (Handler)Class.forName(controllerClassName).newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (handler == null)
			handler = defaultHandler;
		String page = handler.process(req, res);
		
		if (page != null) {
			RequestDispatcher dispatcher = getServletContext()
					.getRequestDispatcher(page);
			dispatcher.forward(req, res);
		}		
	}

	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		processRequest(arg0, arg1);
	}

	protected void doPost(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		processRequest(arg0, arg1);
	}

}
