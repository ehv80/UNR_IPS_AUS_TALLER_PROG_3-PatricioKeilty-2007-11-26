package myblog.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SimpleHandler implements Handler {

	public String process(HttpServletRequest request,
			HttpServletResponse response) {
		String path = request.getServletPath();
		path = path.substring(0, path.indexOf(".do")) + ".jsp";
		return path;
	}

}
