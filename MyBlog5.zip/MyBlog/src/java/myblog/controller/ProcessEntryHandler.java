package myblog.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utils.BlogUtils;

import myblog.BlogEntry;
import myblog.BlogManager;
import myblog.dao.DataAccessException;

public class ProcessEntryHandler implements Handler {

	public String process(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		if (!BlogUtils.isUserAuthorized(request))
			return "/login.do";

		String action = request.getParameter("action");
		if ("entry-delete".equals(action)){
			//delete entry
		    try {
				int entryIndex = Integer.parseInt(request.getParameter("entry_index"));
				BlogEntry entry = BlogManager.getBlogEntryById(entryIndex);
				BlogManager.deleteBlogEntry(entry);
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else
		if ("entry-edit".equals(action)){
			//update entry
		    try {
				int entryIndex = Integer.parseInt(request.getParameter("entry_index"));
				BlogEntry entry = BlogManager.getBlogEntryById(entryIndex);
				entry.setTitle(request.getParameter("title"));
				entry.setBody(request.getParameter("body"));
				BlogManager.updateBlogEntry(entry);
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else
		if ("entry-create".equals(action)){
			//new entry
			try {
				BlogEntry entry = new BlogEntry(request.getParameter("title"),request.getParameter("body"));
				BlogManager.createBlogEntry(entry);
			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		response.sendRedirect("index.do");
		return null;
	}

}
