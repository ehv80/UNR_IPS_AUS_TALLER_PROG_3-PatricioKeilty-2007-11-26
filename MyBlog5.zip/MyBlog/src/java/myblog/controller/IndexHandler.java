package myblog.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import myblog.BlogManager;
import myblog.dao.DataAccessException;

public class IndexHandler implements Handler {

	public String process(HttpServletRequest request,
			HttpServletResponse response) {
		List blogEntries = null;
		try {
			blogEntries = BlogManager.getRecentBlogEntries();
		} catch (DataAccessException e) {
			// TODO implement a error handling strategy
			e.printStackTrace();
		}
		request.setAttribute("blog_entries", blogEntries);
		return "/index.jsp";
	}

}
