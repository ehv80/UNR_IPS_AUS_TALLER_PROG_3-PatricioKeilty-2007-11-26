package myblog.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import myblog.BlogEntry;
import myblog.BlogManager;
import myblog.Comment;
import myblog.dao.DataAccessException;

public class EntryHandler implements Handler {

	public String process(HttpServletRequest request,
			HttpServletResponse response) {
		try {
			int entryIndex = Integer.parseInt(request.getParameter("entry_index"));
			BlogEntry entry = BlogManager.getBlogEntryById(entryIndex);

			if (request.getParameter("new") != null){
				String author = request.getParameter("author");
				String message = request.getParameter("message");
			    Comment comment = new Comment(author, message);
			    BlogManager.addCommentToBlogEntry(entry, comment);
			}
			request.setAttribute("entry", entry);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "/entry.jsp";
	}

}
