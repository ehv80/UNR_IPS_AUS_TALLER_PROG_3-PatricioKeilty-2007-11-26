package myblog.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utils.BlogUtils;

import myblog.BlogEntry;
import myblog.BlogManager;
import myblog.dao.DataAccessException;

public class EntryEditHandler implements Handler {

	public String process(HttpServletRequest request,
			HttpServletResponse response) {
		if (!BlogUtils.isUserAuthorized(request))
			return "/login.do";

		BlogEntry blogEntry = null;
		try {
			// TODO need to distinguish when param does not exists from not valid
			int entryIndex = Integer.parseInt(request.getParameter("entry_index"));
			blogEntry = BlogManager.getBlogEntryById(entryIndex);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("blog_entry", blogEntry);
		return "/edit-entry.jsp";
	}

}
