package myblog.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginHandler implements Handler {

	public String process(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		final String BLOG_USERNAME = "blog";
		final String BLOG_PASS = "blog";

		if (BLOG_USERNAME.equals(username) && BLOG_PASS.equals(password)) {
			request.getSession().setAttribute("blog_user", "authenticated!");
			return "/index.do";
		}
		return "/login_form.jsp";
	}
}
