package utils;

import javax.servlet.http.HttpServletRequest;

public class BlogUtils {

	public static boolean isUserAuthorized(HttpServletRequest request) {
		Object user = request.getSession().getAttribute("blog_user");
		return user != null;
	}
}
